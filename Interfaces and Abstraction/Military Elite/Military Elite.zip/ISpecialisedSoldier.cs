﻿namespace OOPadv

{

    public interface ISpecialisedSoldier

    {

        string Corps { get; }

    }

}