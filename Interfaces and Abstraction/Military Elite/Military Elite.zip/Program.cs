﻿using OOPadv;

using System;

using System.Collections.Generic;

using System.Linq;



public class Program

{

    public static void Main()

    {

        var engine = new Engine();

        engine.Run();

    }

}