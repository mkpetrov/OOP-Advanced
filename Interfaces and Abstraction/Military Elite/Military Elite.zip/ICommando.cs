﻿using System.Collections.Generic;



namespace OOPadv

{

    public interface ICommando

    {

        List<Mission> Missions { get; }

    }

}