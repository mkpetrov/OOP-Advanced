﻿using System.Collections.Generic;



namespace OOPadv

{

    public interface IEngineer

    {

        List<Repair> Repairs { get; }

    }

}