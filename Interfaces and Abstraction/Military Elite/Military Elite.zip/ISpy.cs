﻿namespace OOPadv

{

    public interface ISpy

    {

        int CodeNumber { get; }

    }

}