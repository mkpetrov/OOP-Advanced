﻿public class Pet
{
    public Pet(string birthdate)
    {
        this.Birthdate = birthdate;
    }

    public string Birthdate { get; set; }
}