﻿public interface IPerson
{
    string Id { get; }
}