﻿public interface ICall
{
    string CallNumber { get; }
}