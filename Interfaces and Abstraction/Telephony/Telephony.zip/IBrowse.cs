﻿public interface IBrowse
{
    string Url { get; }
}